To test the project, use `mvn test`
